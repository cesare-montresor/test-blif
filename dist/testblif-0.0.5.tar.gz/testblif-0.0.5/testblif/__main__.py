from .testblif import main

main()